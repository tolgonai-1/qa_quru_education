from selene import browser, have


browser.open('https://www.yahoo.com')
browser.element('[name=p]').type('seleniumhq').press_enter()
browser.element('[id=results]').should(have.text('www.selenium.dev'))