from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


browser = webdriver.Chrome()
browser.get('https://www.yahoo.com')
elem = browser.find_element(By.NAME, 'p')  # Find the search box
elem.send_keys('seleniumhq' + Keys.RETURN)

search_results = browser.find_element(By.ID, 'results')
assert 'www.selenium.dev' in search_results.text

browser.quit()