from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto('https://www.ya.ru')

    page.fill('#text', 'seleniumhq')
    page.keyboard.press('Enter')

    page.wait_for_selector('#search-result')
    search_results = page.locator('#search-result').inner_text()

    assert 'selenium.dev' in search_results

    browser.close()
