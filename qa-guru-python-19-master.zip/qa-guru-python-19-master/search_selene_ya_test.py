from selene import browser, have


browser.open('https://www.ya.ru')
browser.element('[id=text]').type('seleniumhq').press_enter()
browser.element('[id=search-result]').should(have.text('selenium.dev'))