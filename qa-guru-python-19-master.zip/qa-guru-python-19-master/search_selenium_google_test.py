from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


browser = webdriver.Chrome()
browser.get('https://www.google.com')
elem = browser.find_element(By.NAME, 'q')  # Find the search box
elem.send_keys('seleniumhq' + Keys.RETURN)

# todo remove CAPTCHA

search_results = browser.find_element(By.ID, 'search')
assert 'https://www.selenium.dev' in search_results.text

browser.quit()